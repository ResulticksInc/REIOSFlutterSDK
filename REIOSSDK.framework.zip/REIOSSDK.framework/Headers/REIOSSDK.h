//
//  REIOSSDK.h
//  REIOSSDK
//
//  Created by Sivakumar on 14/2/18.
//  Copyright © 2018 Interakt. All rights reserved.
//

#import <UIKit/UIKit.h>


//! Project version number for REIOSSDK.
FOUNDATION_EXPORT double REIOSSDKVersionNumber;

//! Project version string for REIOSSDK.
FOUNDATION_EXPORT const unsigned char REIOSSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <REIOSSDK/PublicHeader.h>


